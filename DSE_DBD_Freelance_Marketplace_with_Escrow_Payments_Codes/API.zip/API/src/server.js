import "dotenv/config";
import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import morgan from "morgan";
import { createProxyMiddleware } from "http-proxy-middleware";

const app = express();
const port = Number(process.env.PORT || 3000);
const springBootUrl = process.env.SPRING_BOOT_URL || "http://localhost:8080";
const allowedOrigins = (process.env.FRONTEND_URL || "http://localhost:5173")
  .split(",")
  .map((origin) => origin.trim());

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin: allowedOrigins,
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
}));
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));
app.use("/api", rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 900000),
  limit: Number(process.env.RATE_LIMIT_MAX || 300),
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." },
}));
app.use("/api", (request, response, next) => {
  const contentLength = Number(request.headers["content-length"] || 0);
  if (contentLength > 1_000_000) {
    response.status(413).json({ error: "Request body exceeds the 1 MB limit." });
    return;
  }
  next();
});

app.get("/health", (_request, response) => {
  response.json({ status: "ok", service: "freelancehub-api", timestamp: new Date().toISOString() });
});

app.use("/api", createProxyMiddleware({
  target: springBootUrl,
  changeOrigin: true,
  secure: process.env.NODE_ENV === "production",
  pathRewrite: { "^/": "/api/" },
  proxyTimeout: 10000,
  timeout: 10000,
  on: {
    error: (_error, _request, response) => {
      if (!response.headersSent) {
        response.status(502).json({ error: "Backend service unavailable." });
      }
    },
  },
}));

app.use((_request, response) => {
  response.status(404).json({ error: "Route not found." });
});

app.listen(port, () => {
  console.log(`FreelanceHub API listening on port ${port}`);
});
